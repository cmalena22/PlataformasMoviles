export class Persona{
    uid:string
    nombre:string 
    correo: string
    mensaje:string 
   // latitude : string
    direccion:string
    image:any;
}