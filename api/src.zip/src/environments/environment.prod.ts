export const environment = {
  production: true,
  firebase:{
    apiKey: "AIzaSyBJJHNg9OjnIzwe664xJEloEwieqhq4p4E",
    authDomain: "pruebas-34b7a.firebaseapp.com",
    projectId: "pruebas-34b7a",
    storageBucket: "pruebas-34b7a.appspot.com",
    messagingSenderId: "276998248848",
    appId: "1:276998248848:web:899b1ac354e476c8a23b15"

  }
};
